package com.beckwith.framework;

public enum ObjectID {
	player,
	garbage,
	background,
	bullet,
	countdown
}
